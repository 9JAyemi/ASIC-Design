if {![namespace exists ::IMEX]} { namespace eval ::IMEX {} }
set ::IMEX::dataVar [file dirname [file normalize [info script]]]
set ::IMEX::libVar ${::IMEX::dataVar}/libs

create_library_set -name lib_scan_hold_ffgnp_0p880v_125c_cbest_CCbest\
   -timing\
    [list ${::IMEX::libVar}/mmmc/N16ADFP_StdCellff0p88v125c_ccs.lib\
    ${::IMEX::libVar}/mmmc/N16ADFP_SRAM_ff0p88v0p88v125c_100a.lib]
create_library_set -name lib_scan_setup_ssgnp_0p720v_m40c_cworst_CCworst\
   -timing\
    [list ${::IMEX::libVar}/mmmc/N16ADFP_StdCellss0p72vm40c_ccs.lib\
    ${::IMEX::libVar}/mmmc/N16ADFP_SRAM_ss0p72v0p72vm40c_100a.lib]
create_rc_corner -name cbest_125c\
   -preRoute_res 1\
   -postRoute_res 1\
   -preRoute_cap 1\
   -postRoute_cap 1\
   -postRoute_xcap 1\
   -preRoute_clkres 0\
   -preRoute_clkcap 0\
   -T 125\
   -qx_tech_file ${::IMEX::libVar}/mmmc/cbest_125c/qrcTechFile
create_rc_corner -name cworst_m40c\
   -preRoute_res 1\
   -postRoute_res 1\
   -preRoute_cap 1\
   -postRoute_cap 1\
   -postRoute_xcap 1\
   -preRoute_clkres 0\
   -preRoute_clkcap 0\
   -T -40\
   -qx_tech_file ${::IMEX::libVar}/mmmc/cworst_m40c/qrcTechFile
create_delay_corner -name scan_setup_ssgnp_0p720v_m40c_cworst_CCworst\
   -library_set lib_scan_setup_ssgnp_0p720v_m40c_cworst_CCworst\
   -rc_corner cworst_m40c
create_delay_corner -name scan_hold_ffgnp_0p880v_125c_cbest_CCbest\
   -library_set lib_scan_hold_ffgnp_0p880v_125c_cbest_CCbest\
   -rc_corner cbest_125c
create_constraint_mode -name scan_setup_ssgnp_0p720v_m40c_cworst_CCworst\
   -sdc_files\
    [list ${::IMEX::dataVar}/mmmc/modes/scan_setup_ssgnp_0p720v_m40c_cworst_CCworst/scan_setup_ssgnp_0p720v_m40c_cworst_CCworst.sdc]
create_constraint_mode -name scan_hold_ffgnp_0p880v_125c_cbest_CCbest\
   -sdc_files\
    [list ${::IMEX::dataVar}/mmmc/modes/scan_hold_ffgnp_0p880v_125c_cbest_CCbest/scan_hold_ffgnp_0p880v_125c_cbest_CCbest.sdc]
create_analysis_view -name scan_setup_ssgnp_0p720v_m40c_cworst_CCworst -constraint_mode scan_setup_ssgnp_0p720v_m40c_cworst_CCworst -delay_corner scan_setup_ssgnp_0p720v_m40c_cworst_CCworst -latency_file ${::IMEX::dataVar}/mmmc/views/scan_setup_ssgnp_0p720v_m40c_cworst_CCworst/latency.sdc
create_analysis_view -name scan_hold_ffgnp_0p880v_125c_cbest_CCbest -constraint_mode scan_hold_ffgnp_0p880v_125c_cbest_CCbest -delay_corner scan_hold_ffgnp_0p880v_125c_cbest_CCbest -latency_file ${::IMEX::dataVar}/mmmc/views/scan_hold_ffgnp_0p880v_125c_cbest_CCbest/latency.sdc
set_analysis_view -setup [list scan_setup_ssgnp_0p720v_m40c_cworst_CCworst] -hold [list scan_hold_ffgnp_0p880v_125c_cbest_CCbest]
catch {set_interactive_constraint_mode [list scan_setup_ssgnp_0p720v_m40c_cworst_CCworst scan_hold_ffgnp_0p880v_125c_cbest_CCbest] } 
